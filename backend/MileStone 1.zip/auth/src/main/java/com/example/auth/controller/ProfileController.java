package com.example.auth.controller;

import com.example.auth.entity.User;
import com.example.auth.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/profile")
@RequiredArgsConstructor
public class ProfileController {

    private final AuthService authService;

    @GetMapping
    public ResponseEntity<User> getProfile(@AuthenticationPrincipal User currentUser) {
        // Returns the currently authenticated user automatically injected by Spring Security
        return ResponseEntity.ok(currentUser);
    }

    @PutMapping
    public ResponseEntity<String> updateProfile(@AuthenticationPrincipal User currentUser, @RequestBody Map<String, String> updates) {
        // In a real application, you would map 'updates' to the user entity and save it
        return ResponseEntity.ok("Profile updated for user: " + currentUser.getUsername());
    }

    @PostMapping("/change-password")
    public ResponseEntity<String> changePassword(@AuthenticationPrincipal User currentUser, @RequestBody Map<String, String> request) {
        authService.changePassword(
                currentUser.getUsername(), 
                request.get("oldPassword"), 
                request.get("newPassword")
        );
        return ResponseEntity.ok("Password changed successfully.");
    }
}