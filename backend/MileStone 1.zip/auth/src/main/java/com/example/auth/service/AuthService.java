package com.example.auth.service;

import com.example.auth.dto.LoginRequest;
import com.example.auth.dto.LoginResponse;
import com.example.auth.dto.RegisterRequest;
import com.example.auth.dto.RegisterResponse;
import com.example.auth.entity.User;
import com.example.auth.entity.Role; // Added the Role import! Adjust if your folder is different.
import com.example.auth.repository.UserRepository;
import com.example.auth.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;

    public RegisterResponse register(RegisterRequest request) {
        // Build the new user
        User user = new User();
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        
        // FIX 1: Removed 'User.' so it correctly uses the standalone Role class
        user.setRole(Role.valueOf(request.getRole().toUpperCase())); 

        userRepository.save(user);

        // FIX 2: Passing the entire 'user' object instead of just the username string
        String jwtToken = jwtUtil.generateToken(user); 
        return new RegisterResponse(jwtToken, "User registered successfully");
    }

    public LoginResponse login(LoginRequest request) {
        // This will throw an exception if credentials are wrong
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getUsername(),
                        request.getPassword()
                )
        );

        // If we get here, credentials are correct. Fetch user and generate token.
        var user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        // FIX 2: Passing the entire 'user' object instead of just the username string
        String jwtToken = jwtUtil.generateToken(user);
        return new LoginResponse(jwtToken, "Login successful");
    }

    public void forgotPasswordSkeleton(String email) {
        // Skeleton method: In a production environment, this would generate a secure, 
        // time-sensitive token and trigger an email using JavaMailSender.
        System.out.println("Password reset link requested for: " + email);
    }

    public void changePassword(String username, String oldPassword, String newPassword) {
        // 1. Find the user
        var user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        // 2. Verify the old password matches what is currently in the database
        if (!passwordEncoder.matches(oldPassword, user.getPassword())) {
            throw new RuntimeException("Incorrect old password!");
        }
        
        // 3. Encrypt the new password and update the database
        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);
    }
}