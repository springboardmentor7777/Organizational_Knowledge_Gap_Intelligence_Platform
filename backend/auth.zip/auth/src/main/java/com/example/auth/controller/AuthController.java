package com.example.auth.controller;

import com.example.auth.dto.LoginRequest;
import com.example.auth.dto.LoginResponse;
import com.example.auth.dto.RegisterRequest;
import com.example.auth.dto.RegisterResponse;
import com.example.auth.entity.User;
import com.example.auth.exception.ResourceNotFoundException;
import com.example.auth.exception.UnauthorizedException;
import com.example.auth.repository.UserRepository;
import com.example.auth.security.JwtUtil;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;


@RestController
@RequestMapping("/auth")
public class AuthController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;


    public AuthController(UserRepository userRepository,
                          PasswordEncoder passwordEncoder,
                          JwtUtil jwtUtil) {

        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }


    // Test API
    @GetMapping("/test")
    public String test() {
        return "Auth working";
    }


    // Register API
    @PostMapping("/register")
    public RegisterResponse register(
            @RequestBody RegisterRequest request) {


        if (request.getUsername() == null ||
            request.getEmail() == null ||
            request.getPassword() == null) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Username, email and password are required"
            );
        }


        if (userRepository.findByUsername(request.getUsername()).isPresent()) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Username already exists"
            );
        }


        User user = new User();

        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());

        user.setPassword(
                passwordEncoder.encode(request.getPassword())
        );


        userRepository.save(user);


        return new RegisterResponse(
                "User registered successfully"
        );
    }



    // Login API
    @PostMapping("/login")
    public LoginResponse login(
            @RequestBody LoginRequest request) {


        User user = userRepository
                .findByUsername(request.getUsername())
                .orElseThrow(() ->
                        new UnauthorizedException(
                                "Invalid username or password"
                        ));


        if (!passwordEncoder.matches(
                request.getPassword(),
                user.getPassword())) {

            throw new UnauthorizedException(
                    "Invalid username or password"
            );
        }


        String token =
                jwtUtil.generateToken(
                        user.getUsername()
                );


        return new LoginResponse(
                "Login successful",
                token
        );
    }



    // Profile API
    @GetMapping("/profile")
    public User profile(Authentication authentication) {


        if (authentication == null) {

            throw new UnauthorizedException(
                    "Missing or invalid token"
            );
        }


        String username =
                authentication.getName();


        return userRepository
                .findByUsername(username)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User not found"
                        ));
    }



    // Logout API
    @PostMapping("/logout")
    public RegisterResponse logout() {

        return new RegisterResponse(
                "Logout successful"
        );
    }
}