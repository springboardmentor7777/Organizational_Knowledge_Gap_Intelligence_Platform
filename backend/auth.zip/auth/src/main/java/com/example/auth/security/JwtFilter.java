package com.example.auth.security;

import java.io.IOException;
import java.util.Collections;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.lang.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;


@Component
public class JwtFilter extends OncePerRequestFilter {


    @Autowired
    private JwtUtil jwtUtil;


    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain)
            throws ServletException, IOException {


        String path = request.getRequestURI();


        // Only skip public APIs
        if (path.equals("/auth/login")
                || path.equals("/auth/register")
                || path.equals("/auth/test")
                || path.startsWith("/h2-console/")) {

            filterChain.doFilter(request, response);
            return;
        }


        String header = request.getHeader("Authorization");


        if (header == null || !header.startsWith("Bearer ")) {

            response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED
            );

            response.getWriter()
                    .write("Missing token");

            return;
        }


        String token = header.substring(7);


        if (!jwtUtil.isValidToken(token)) {

            response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED
            );

            response.getWriter()
                    .write("Invalid token");

            return;
        }


        String username =
                jwtUtil.extractUsername(token);



        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken(
                        username,
                        null,
                        Collections.emptyList()
                );


        authentication.setDetails(
                new WebAuthenticationDetailsSource()
                        .buildDetails(request)
        );


        SecurityContextHolder
                .getContext()
                .setAuthentication(authentication);



        filterChain.doFilter(request, response);
    }
}