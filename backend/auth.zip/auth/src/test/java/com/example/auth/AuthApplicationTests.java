package com.example.auth;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.blankOrNullString;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@SpringBootTest
@AutoConfigureMockMvc
class AuthApplicationTests {


    @Autowired
    private MockMvc mockMvc;



    @Test
    void contextLoads() {
    }



    @Test
    void authSkeletonEndpointsWork() throws Exception {


        // REGISTER

        mockMvc.perform(post("/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content("""
                {
                  "username": "harsh",
                  "email": "harsh@example.com",
                  "password": "1234"
                }
                """))

                .andExpect(status().isOk())
                .andExpect(
                    jsonPath("$.message")
                    .value("User registered successfully")
                );



        // LOGIN

        String response =
                mockMvc.perform(post("/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content("""
                {
                  "username": "harsh",
                  "password": "1234"
                }
                """))

                .andExpect(status().isOk())
                .andExpect(
                    jsonPath("$.message")
                    .value("Login successful")
                )
                .andExpect(
                    jsonPath("$.token")
                    .value(not(blankOrNullString()))
                )

                .andReturn()
                .getResponse()
                .getContentAsString();



        String token =
                response.split("\"token\":\"")[1]
                        .split("\"")[0];



        // PROFILE

        mockMvc.perform(get("/auth/profile")
                .header(
                    "Authorization",
                    "Bearer " + token
                ))

                .andExpect(status().isOk())
                .andExpect(
                    jsonPath("$.username")
                    .value("harsh")
                );



        // LOGOUT

        mockMvc.perform(post("/auth/logout")
                .header(
                    "Authorization",
                    "Bearer " + token
                ))

                .andExpect(status().isOk())
                .andExpect(
                    jsonPath("$.message")
                    .value("Logout successful")
                );
    }
}