package com.knowledgegap.knowledgegapplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KnowledgeGapPlatformApplication {

    public static void main(String[] args) {
        SpringApplication.run(KnowledgeGapPlatformApplication.class, args);
    }

}
